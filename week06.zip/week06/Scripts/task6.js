//hyrum bullock 2023



async function openJson(url){
    // feches a response and waits for it
    var responce = await fetch(url);
    // continues only if it gets the ok from the fetch
    if(responce.ok){
        const data = await responce.json();
        return data;
    }
}


function createObject(jsonFile, rand){

    var jsonDict = jsonFile[rand];
    
    //creates an object to hold the JSON dictionary data pulled from an array
    var gundamInfo = {};
    gundamInfo.title = jsonDict["gundamName"]
    gundamInfo.text = jsonDict["gundamText"]
    gundamInfo.img = jsonDict["gundamImgURL"]

    return gundamInfo;
}

function replacePageContent(gundamInfo, num){

    //sets the html elements to the values stored in the objects 
    document.getElementById("gundTitle"+ num).textContent = gundamInfo.name;
    document.getElementById("textWall" + num).textContent = gundamInfo.text;
    document.getElementById("gundImg"+ num).src = gundamInfo.img
}

function randomise(){

    var randArray = [];
    var randDupe = -1;

    //this lessens the chance of getting a duplicat number
    while (randArray.length < 3){
        var rand = Math.floor(Math.random() * 6);
        // checks to be sure the new number doesnt match the previous one and
        if (randDupe == rand){
            rand = Math.floor(Math.random() * 6);
        }

        randDupe = rand;
        randArray.push(rand);
        //prints the array for debuging
        //console.log(randArray)
    }

    // these .then statements were a pain in the neck to figure out
    //this opens the json then once it gets the json file's data it allows it to execute the sode
    openJson('gundams.json').then((gundamJson)=> {
        //the old randomisation it was prone to having the same numbers
        // var rand1 = Math.floor(Math.random() * 6);
        // var rand2 = Math.floor(Math.random() * 6);
        // var rand3 = Math.floor(Math.random() * 6);

        let gundamObj = createObject(gundamJson, randArray[0]);
        replacePageContent(gundamObj, 1);

        gundamObj = createObject(gundamJson, randArray[1]);
        replacePageContent(gundamObj, 2);

        gundamObj = createObject(gundamJson, randArray[2]);
        replacePageContent(gundamObj, 3);

        
    });
}

function restore(){
    // does the same as line 58 so go look at line 57 if you wana know
    openJson('gundams.json').then((gundamJson)=> {

        let gundamObj = createObject(gundamJson, 0);
        replacePageContent(gundamObj, 1);

        gundamObj = createObject(gundamJson, 1);
        replacePageContent(gundamObj, 2);

        gundamObj = createObject(gundamJson, 2);
        replacePageContent(gundamObj, 3);
    });

}


document.getElementById("randomise").addEventListener("click", randomise);
document.getElementById("restore").addEventListener("click", restore);
